$(document).ready
(
	function()
	{
		$("#set").click
		(
			function(e)
			{
				setCookie($("#cookieName").val(),
						  $("#cookieValue").val(),
						  1);
			}//end set handler
		);//end set click
		
		$("#get").click
		(
			function(e)
			{
				getCookie($("#cookieName").val());
			}//end get handler
		);//end get click
		
		$('#delete').click
		(
			function(e)
			{
				setCookie($("#cookieName").val(),
						"",
						-1);
			}
		);// end delete click
		displayCookies();
	}//end ready function
);

//set values from html
function setCookie(name, value, days)
{
	//get date info for expiration
	var docDate = new Date();
	docDate.setTime(docDate.getTime() + (days*24*60*60*1000));
	var expires = "; expries = " + docDate.toGMTString();
	document.cookie = name + " = " + value + expires;
	displayCookies();
}//end set function

//retrieve values for html
function getCookie(name)
{
	var ckName = $("#cookieName").val();
	var cookieArr = document.cookie.split(';');
	
	for(var i=0; i < cookieArr.length; i++)
	{
		var cookie = cookieArr[i];
		while(cookie.charAt(0)==' ')
		{
			cookie.substring(1,cookie.length);
		}//end while
		
		if(cookie.indexOf(ckName) == 0)
		{
			$("#cookieValue").val(cookie.substring(ckName.length, cookie.length));
			break;
		}//end if
	}//end for
}//end function


//display the cookie details
function displayCookies()
{
	$("#cookieList").html("");
	var cookieArr = document.cookie.split(';');
	
	for(var i=0; i < cookieArr.length; i++)
	{
		var cookie = cookieArr[i];
		$("#cookieList").append($("<li></li>").html (cookie));
	}//end for
}//end displayCookies
