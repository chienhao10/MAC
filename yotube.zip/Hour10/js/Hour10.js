$(document).ready
(
	function()
	{
		$(document).mousemove(mousePosition);
		$("*").mouseover(elementInfo);
		$("*").change(elementInfo);
		$("*").keypress(elementInfo);
		$(window).resize(windowsResize);
	}//end function calls
);//end ready

function mousePosition(e)
{
	e.stopPropagation(e);//page 227
	$("#screenSize").html(screen.width + "x" + screen.height);
	$("#browserSize").html(window.innerWidth + "x" + window.height);
}//end mousePosition

//Handle changes in windows size
function windowsResize(e)
{
	$("#browserSize").html(window.innerWidth + "x" + window.height);
}//end windowsResize

//Return values of HTML element (DOM)
function elementInfo(e)
{
	//Window & Browser
	e.stopPropagation(e);
	$("#infoContainer span").html("");
	var domObj = e.target;
	var jObj = $(domObj);
	
	//Text in the box
	$("elementID").html(domObj.id);
	$("elementType").html(jObj.prop('tagName'));
	$("#elementClass").html(domObj.className);
	$("elementSize").html(jObj.width() + "x" + jObj.height());
	$("elementPosition").html(jObj.offset().top + "," + jObj.offset().left);
	$("elementValue").html(jObj.val());
	$("elementChecked").html(jObj.val());
}//end elementInfo
